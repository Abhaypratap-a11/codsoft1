# Portfolio_Website


<h1 align="center">Hi I am Ayush Shyam Lingayat</h1>
<h3 align="center">I Am a Front End Developer from India</h3>

## Website Preview
#### Portfolio Page





<img src="portfolio_1.png" width="900">

<img src="portfolio_2.png" width="900">

<img src="portfolio_3.png" width="900">
  






- 💬 Ask me about **Designing and Development**

- 📫 How to reach me **lingayatayush3@gmail.com**

- ⚡ Fun fact **Coding is never ending process**









<h3 align="left">Connect with me:</h3>
<p align="left">
<a href="https://www.linkedin.com/in/ayush-lingayat/" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/linked-in-alt.svg" alt="https://www.linkedin.com/in/ayush-lingayat/" height="30" width="40" /></a>
<a href="https://www.hackerrank.com/@lingayatayush3" target="blank"><img align="center" src="https://raw.githubusercontent.com/rahuldkjain/github-profile-readme-generator/master/src/images/icons/Social/hackerrank.svg" alt="@lingayatayush3" height="30" width="40" /></a>
</p>








## Tools Used 🛠️
* <b>GitHub Pages</b> - To host my static website (HTML, CSS, JS).
